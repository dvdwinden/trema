# Trema

A custom Ghost theme for my Trema publication.

## Installation

Upload the theme zip to **Ghost Admin** → **Design** → **Change theme**

## License

This theme is licensed under the Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0) License.  
You are free to use, share, and adapt this theme for non-commercial purposes, with attribution.  
For more information, see the [LICENSE](LICENSE) file or visit https://creativecommons.org/licenses/by-nc/4.0/
